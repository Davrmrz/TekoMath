"""Core localization modules."""
